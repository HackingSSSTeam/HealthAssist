package com.mycompany.javafxstartfall2020;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class Main  {


    public static void main(String[] args) {
        App.main(args);
    }

}