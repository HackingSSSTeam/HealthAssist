/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.javafxstartfall2020;

/**
 *
 * @author shubi
 */
public class Info {
    String bodyPart;
    String[] symptoms;
    
    Info(String bodyPart, String[] symptoms){
        this.bodyPart = bodyPart;
        this.symptoms = symptoms;
    }
}
