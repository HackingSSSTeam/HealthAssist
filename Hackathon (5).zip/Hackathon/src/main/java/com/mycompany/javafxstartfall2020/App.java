package com.mycompany.javafxstartfall2020;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import static javafx.scene.paint.Color.color;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class App extends Application {

    Stage window;
    ArrayList<String> selectedSympts;
    Scene analysisScene, partsScene;
    String disease;
    HBox topMenu = new HBox(8);
    ArrayList<Info> allBodyPartsList;
    float percentage;

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) {
        window = stage;
        window.setTitle("Diseases and their Symptoms");

        ArrayList<Disease> allDiseases = diseases();
        uniqueSymp(allDiseases);
        //System.out.println(allDiseases);

        //make grid pane
        GridPane symptomsCheck = new GridPane();
        symptomsCheck.setPadding(new Insets(10, 10, 10, 10));
        symptomsCheck.setVgap(8);
        symptomsCheck.setHgap(8);

        ArrayList<CheckMenuItem> options = new ArrayList<>();
        //MenuBar menuBar = new MenuBar();
        VBox vbox = new VBox();
        for (int i = 0; i < allBodyPartsList.size(); i++) {
            //Label label = new Label(allBodyPartsList.get(i).bodyPart + ": ");
            //GridPane.setConstraints(label, 0, i);
            Menu menu = new Menu(allBodyPartsList.get(i).bodyPart);
            //VBox checkList = new VBox(8);
            for (int j = 0; j < allBodyPartsList.get(i).symptoms.length; j++) {
                CheckMenuItem symptom = new CheckMenuItem(allBodyPartsList.get(i).symptoms[j]);
                symptom.setSelected(false);
                //checkList.getChildren().add(symptom);
                menu.getItems().add(symptom);
                options.add(symptom);
            }
            //GridPane.setConstraints(checkList, 1, i);
            //symptomsCheck.getChildren().addAll(label, checkList);
            MenuBar menuBar = new MenuBar();
            menuBar.getMenus().add(menu);
            vbox.getChildren().add(menuBar);
        }
        GridPane.setConstraints(vbox, 0, 2);

        //make label
        Label intstructions = new Label("Select afflicted areas and details: ");
        intstructions.setTextFill(Color.WHITE);
        GridPane.setConstraints(intstructions, 0, 1);

        //make button
        Button submitSympt = new Button("Submit");
        submitSympt.setOnAction(e -> {
            analyze(options);
        });
        GridPane.setConstraints(submitSympt, 0, 3);

        ScrollPane sp = new ScrollPane(symptomsCheck);
        Scene symptScene = new Scene(sp, 410, 600);

        Button restart = new Button("Home");
        restart.setOnAction(e -> {
            topMenu.getChildren().clear();
            start(window);
        });

        Button covid = new Button("Covid-19");
        covid.setOnAction(e -> covidScene());

        Button allSymp = new Button("Diseases");
        allSymp.setOnAction(e -> diseaseScene());

        topMenu.getChildren().addAll(restart, covid, allSymp);
        
        GridPane.setConstraints(topMenu, 0, 0);
        
        
        //Stop[] stops = new Stop[] {new Stop(0, Color.GRAY), new Stop(1, Color.WHITE)};
//        LinearGradient lg1 = new LinearGradient(0,0,1,0,true,CycleMethod.NO_CYCLE, stops);
//        symptomsCheck.setFill(lg1);
        //sp.setStyle("-fx-background-color:gray");
        
        symptomsCheck.getChildren().addAll(topMenu, intstructions, vbox, submitSympt);
        vbox.setAlignment(Pos.CENTER);
        symptomsCheck.setMinWidth(410);
        vbox.setMaxWidth(410);
        vbox.setStyle("-fx-background-color:gray");
        symptomsCheck.setStyle("-fx-background-color:gray");
        
        
        //setUserAgentStylesheet("https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css");
        stage.setScene(symptScene);
        

        window.show();
    }

    public void diseaseScene() {
        BorderPane bp = new BorderPane();
        bp.setPadding(new Insets(10, 10, 10, 10));

        bp.setTop(topMenu);

        ArrayList<String> diseases = readFile("/diseases.txt", ",");
        ChoiceBox<String> disease = new ChoiceBox();
        for (String dis : diseases) {
            disease.getItems().add(dis);
        }

        Button submit = new Button("Submit");
        Label start = new Label("Select a disease to find out its symptoms: ");
        start.setTextFill(Color.WHITE);
        VBox vbox = new VBox(8);
        vbox.setStyle("-fx-background-color:grey");
        Label blank = new Label("   ");
        vbox.getChildren().addAll(start, disease, submit, blank);
        Label syms = new Label("");
        syms.setTextFill(Color.WHITE);
        submit.setOnAction(e -> {
            syms.setText(symptomsForDisease(disease.getValue()));
            vbox.getChildren().add(syms);
        });
        
        vbox.setAlignment(Pos.CENTER);
        bp.setCenter(vbox);

        Scene diseaseScene = new Scene(bp, 410, 600);
        
        window.setScene(diseaseScene);
    }

    public String symptomsForDisease(String disease) {
        ArrayList<Disease> DSW = diseases();
        String syms = "";
        for (Disease dis : DSW) {
            if (dis.name.equals(disease)) {
                syms = dis.toString();
            }
        }
        return syms;
    }

    public void covidScene() {
        BorderPane bp = new BorderPane();
        bp.setPadding(new Insets(10, 10, 10, 10));

        bp.setTop(topMenu);

        VBox center = new VBox(8);
        Label graphL = new Label("View a graph of the current covid-19 cases in the US- ");
        graphL.setTextFill(Color.WHITE);
        Button graph = new Button("Graph");
        graph.setOnAction(e -> graph());
        Label blank = new Label("   ");
        Label covidWarning = new Label("If you experience any of the following please refer to a hospital\n       immediately. You may be experiencing the coronavirus!");
        covidWarning.setTextFill(Color.WHITE);
        covidWarning.setStyle("-fx-font-weight: bold;");
        Label covidSym = new Label("                •fever\n                •chills\n                •cough\n"
                + "                •shortness of breath\n                •nausea\n                •diarrhea\n "
                + "                •vomiting\n                •headache\n                •fatigue\n"
                + "                •sore throat\n                •runny nose\n                •loss of taste");
        covidSym.setTextFill(Color.WHITE);
        center.getChildren().addAll(graphL, graph, blank, covidWarning, covidSym);

        center.setAlignment(Pos.CENTER);
        center.setStyle("-fx-background-color:grey");
        bp.setCenter(center);

        Scene covid19Scene = new Scene(bp, 410, 600);
        covid19Scene.getStylesheets().add("/LineChart.css");
        window.setScene(covid19Scene);
    }

    public void graph() {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("AMOUNT OF CASES");
        final LineChart<String, Number> lineChart = new LineChart<String, Number>(xAxis, yAxis);
        lineChart.setTitle("COVID CASES IN THE LAST 10 DAYS");
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("US (RED)");
        series1.getData().add(new XYChart.Data("Oct 29", 81802));
        series1.getData().add(new XYChart.Data("Oct 30", 90728));
        series1.getData().add(new XYChart.Data("Oct 31", 99784));
        series1.getData().add(new XYChart.Data("Nov 1", 84285));
        series1.getData().add(new XYChart.Data("Nov 2", 74236));
        series1.getData().add(new XYChart.Data("Nov 3", 93642));
        series1.getData().add(new XYChart.Data("Nov 4", 92599));
        series1.getData().add(new XYChart.Data("Noc 5", 107872));
        series1.getData().add(new XYChart.Data("Nov 6", 121504));
        series1.getData().add(new XYChart.Data("Nov 7", 132797));

        XYChart.Series series2 = new XYChart.Series();

        series2.setName("WORLD (ORANGE)");
        series2.getData().add(new XYChart.Data("Oct 29", 552456));
        series2.getData().add(new XYChart.Data("Oct 30", 489228));
        series2.getData().add(new XYChart.Data("Oct 31", 505854));
        series2.getData().add(new XYChart.Data("Nov 1", 598195));
        series2.getData().add(new XYChart.Data("Nov 2", 481624));
        series2.getData().add(new XYChart.Data("Nov 3", 443316));
        series2.getData().add(new XYChart.Data("Nov 4", 429414));
        series2.getData().add(new XYChart.Data("Noc 5", 570988));
        series2.getData().add(new XYChart.Data("Nov 6", 540313));
        series2.getData().add(new XYChart.Data("Nov 7", 581679));

        Scene scene  = new Scene(lineChart,800,600);
        lineChart.getData().addAll(series1, series2);

        Stage stage = new Stage();
        stage.setScene(scene);
        stage.showAndWait();
    }

    public void clearChecks(ArrayList<CheckMenuItem> symptList) {
        for (CheckMenuItem sympt : symptList) {
            sympt.setSelected(false);
        }
        selectedSympts.clear();
    }

    public void makeAnalysisScene() {
        //make bp for analysisScene
        BorderPane analysisBP = new BorderPane();
        analysisBP.setPadding(new Insets(10, 10, 10, 10));

        VBox center = new VBox(15);
        center.setStyle("-fx-background-color:grey");
        Label analysis = new Label("You have a " + Math.round(percentage) + "% chance of having\n               " +disease + ".");
        analysis.setTextFill(Color.WHITE);
        analysis.setStyle("-fx-font: 24 arial;");

        Label webLabel = new Label("To get better, refer to the following websites- ");
        webLabel.setTextFill(Color.WHITE);
        String sites = "";
        ArrayList<HTGBWW> arrSites = howToGetBetter();

        if (disease.equals("no disease")) {
            webLabel.setText("");
            sites = "If you feel otherwise, you can drink hot tea, stay warm,\n                      and if needed, see the doctor.";
        } else {
            for (HTGBWW site : arrSites) {
                if (site.name.equals(disease)) {
                    sites += site.link;
                    if (sites.length() >= 40) {
                        String newSites = sites.substring(0, sites.length() / 2) + "\n" + sites.substring(sites.length() / 2, sites.length());
                        sites = newSites;
                    }
                }
            }
        }
        Hyperlink websites = new Hyperlink(sites);
        websites.setOnAction(e -> getHostServices().showDocument(websites.getText()));

        //Label websites = new Label(sites);
        websites.setTextFill(Color.WHITE);

        center.getChildren().addAll(analysis, webLabel, websites);
        center.setAlignment(Pos.CENTER);

        analysisBP.setCenter(center);
        analysisBP.setTop(topMenu);
        
        analysisScene = new Scene(analysisBP, 410, 600);
        analysisScene.getStylesheets().add("/LineChart.css");
    }

    public static ArrayList<HTGBWW> howToGetBetter() {
        ArrayList<HTGBWW> HTGBWWEBSITES = new ArrayList<>();
        ArrayList<String> links = readFile("/HTGBWW.txt", "\n");
        ArrayList<String> diseases = readFile("/diseases.txt", ",");
        for (int i = 0; i < diseases.size(); i++) {
            HTGBWWEBSITES.add(new HTGBWW(diseases.get(i), links.get(i)));
        }
        System.out.println(HTGBWWEBSITES);
        return HTGBWWEBSITES;
    }

    public String getDisease(ArrayList<String> yourSymptoms) {
        if (selectedSympts.size() == 0) {
            return "no disease";
        }

        ArrayList<Disease> disease = diseases();

        ArrayList<String> uniqueYourSymptoms = new ArrayList<>();
        for (int i = 0; i < yourSymptoms.size(); i++) {
            if (!uniqueYourSymptoms.contains(yourSymptoms.get(i))) {
                uniqueYourSymptoms.add(yourSymptoms.get(i));
            }
        }
        ArrayList<ArrayList<String>> symptoms = new ArrayList<>();
        for (int i = 0; i < disease.size(); i++) {
            ArrayList<String> symptom = new ArrayList<>();
            for (int j = 0; j < disease.get(i).bodyPartSymptoms.length; j++) {
                for (int k = 0; k < disease.get(i).bodyPartSymptoms[j].symptoms.length; k++) {
                    if (!symptom.contains(disease.get(i).bodyPartSymptoms[j].symptoms[k])) {
                        symptom.add(disease.get(i).bodyPartSymptoms[j].symptoms[k]);
                    }
                }
            }
            symptoms.add(symptom);
        }

        int max = 0;
        String diseaseName = "None";

        for (int i = 0; i < symptoms.size(); i++) {
            int count = 0;
            for (int j = 0; j < uniqueYourSymptoms.size(); j++) {
                if (symptoms.get(i).contains(uniqueYourSymptoms.get(j))) {
                    count++;
                }
            }
            if (count > max) {
                max = count;
                diseaseName = disease.get(i).name;
                float total = 0;
                for (int j = 0; j < disease.get(i).bodyPartSymptoms.length; j++) {
                    total += disease.get(i).bodyPartSymptoms[j].symptoms.length;
                }
                percentage = (float) count / total * 100;
                System.out.println(percentage);
            }
        }
        
        return diseaseName;
    }

    public void analyze(ArrayList<CheckMenuItem> symptList) {
        getSelectedSympts(symptList);
        disease = getDisease(selectedSympts);
        makeAnalysisScene();
        window.setScene(analysisScene);
    }

    public void getSelectedSympts(ArrayList<CheckMenuItem> symptList) {
        ArrayList<String> yourSympts = new ArrayList<>();

        for (CheckMenuItem check : symptList) {
            if (check.isSelected()) {
                yourSympts.add(check.getText());
            }
        }
        selectedSympts = yourSympts;
    }

    public ArrayList<Disease> diseases() {
        ArrayList<String> diseases = readFile("/diseases.txt", ",");
        ArrayList<String> symptoms = readFile("/symptoms.txt", ":");
        ArrayList<String> bodyPart = readFile("/bodypart.txt", ":");
        ArrayList<Disease> DWS = new ArrayList<>();

        //System.out.println(diseases.get(0));
        for (int i = 0; i < diseases.size(); i++) {
            Disease disease = new Disease(diseases.get(i), symptoms.get(i).split(";"), bodyPart.get(i).split(","));
            DWS.add(disease);
        }
        return DWS;
    }

    public static ArrayList<String> readFile(String path, String split) {
        ArrayList<String> words = new ArrayList<>();
        String Words;

        InputStream is = App.class.getResourceAsStream(path);
        if (is == null) {
            System.out.println("Disease Not Found");
            System.exit(-1);
        } // checking to make sure the file exists

        // goes through useless words and adds them to the arraylist
        Scanner text = new Scanner(is).useDelimiter("\\s*" + split + "\\s*");
        while (text.hasNext()) {
            Words = text.next();
            //System.out.println(Words);
            words.add(Words); // adding them to the arraylist

        }
        return words;
    }

    public void uniqueSymp(ArrayList<Disease> SOB) {
        ArrayList<Disease> Disease = diseases();
        ArrayList<Info> uniqueSet = new ArrayList<>();
        ArrayList<String> bodies = new ArrayList<>();

        for (int i = 0; i < Disease.size(); i++) {
            for (int j = 0; j < Disease.get(i).bodyPartSymptoms.length; j++) {
                if (!bodies.contains(Disease.get(i).bodyPartSymptoms[j].bodyPart)) {
                    bodies.add(Disease.get(i).bodyPartSymptoms[j].bodyPart);
                }
            }
        }

        for (int i = 0; i < bodies.size(); i++) {
            ArrayList<String> symptoms = new ArrayList<>();
            for (int j = 0; j < Disease.size(); j++) {
                Disease SepDisease = Disease.get(j);
                for (int k = 0; k < SepDisease.bodyPartSymptoms.length; k++) {
                    Info SepInfo = SepDisease.bodyPartSymptoms[k];
                    if (SepInfo.bodyPart.equals(bodies.get(i))) {
                        for (int h = 0; h < SepInfo.symptoms.length; h++) {
                            String SepSymp = SepInfo.symptoms[h];
                            if (!symptoms.contains(SepSymp)) {
                                symptoms.add(SepSymp);
                            }
                        }
                    }
                }
            }
            String[] symptomsArray = new String[symptoms.size()];
            for (int j = 0; j < symptoms.size(); j++) {
                symptomsArray[j] = symptoms.get(j);
            }
            if (bodies.get(i).equals("empty")) {
                uniqueSet.add(new Info("General", symptomsArray));
            } else {
                uniqueSet.add(new Info(bodies.get(i), symptomsArray));
            }
        }

        allBodyPartsList = uniqueSet;
    }
}
