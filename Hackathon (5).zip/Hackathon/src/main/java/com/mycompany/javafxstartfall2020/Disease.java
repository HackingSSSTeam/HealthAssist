/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.javafxstartfall2020;

import java.util.ArrayList;

/**
 *
 * @author shubi
 */
public class Disease {
    String name;
    Info[] bodyPartSymptoms;
    
    Disease(String name, String[] symptoms, String[] bodyParts){
        this.name = name;
        Info[] bodyPS = new Info[bodyParts.length];
        for (int i = 0; i < bodyParts.length; i++) {
            bodyPS[i] = new Info(bodyParts[i], symptoms[i].split(","));
        }
        this.bodyPartSymptoms = bodyPS;        
    }
    
    @Override
    public String toString(){
        String finalDisease = "";
        boolean done = true;
        finalDisease += this.name + "-\n\n";
        for (int i = 0; i < bodyPartSymptoms.length; i++){
            if (bodyPartSymptoms[i].bodyPart.equals("empty")){
                finalDisease += "General:";   
            }
            else{
                finalDisease += bodyPartSymptoms[i].bodyPart + ":";   
            }
           
            for (int j = 0; j < (bodyPartSymptoms[i].symptoms).length; j++){
                finalDisease += " " + bodyPartSymptoms[i].symptoms[j];
                if (j < (bodyPartSymptoms[i].symptoms).length - 1){
                    finalDisease += ",";
                }
                if (j > 1 && done){
                        finalDisease += "\n         ";
                        done = false;
                }
            }
            finalDisease += "\n";
        }
        return finalDisease;
    }
}
