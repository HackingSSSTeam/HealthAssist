module com.mycompany.javafxstartfall2020 {
    requires javafx.controls;
    exports com.mycompany.javafxstartfall2020;
}